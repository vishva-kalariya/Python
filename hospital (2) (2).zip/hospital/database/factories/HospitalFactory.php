<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Hospital>
 */
class HospitalFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        // $table->string("name");
        //     $table->decimal("mobile",10,0);
        //     $table->longText("disease");
        //     $table->longText("medicines");
        return [
           'name' => fake()->name(),
           'mobile' =>fake()->phonenumber,
           'disease' => fake()->sentences(3,true),
           'medicines' => fake()->sentences(5,true)
        ];
    }
}
