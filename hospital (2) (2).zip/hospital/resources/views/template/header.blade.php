<h1> V and M hospital</h1>
@include('template.menu')

