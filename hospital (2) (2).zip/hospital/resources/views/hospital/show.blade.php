@extends('template.layout')
@section('content')
<h1>Patients Details..</h1>
<h5>{{$hospital->name}}</h5>
Medicines:
<h6>{{$hospital->medicines}}</h6>
Disease:
<h6>{{$hospital->disease}}</h6>

@php
$i=1;
@endphp
<ul>
    @forelse($hospital->getVisits as $visit)
     <li>
        <lable for="">visits {{$i++}}</lable>
        <p> {{ $visit->disease}}</p>
    </li>
    @empty
    <li> No more visits found</li>

    @endforelse
</ul>

<form action="{{route('visit.store')}}"method="post">
    @csrf
    <input type="hidden" name="patients_id" value={{$hospital->id}}>
    <div class="form-group">
        <label>Example textarea</label>
          <textarea name="disease" class="form-control" rows="3"></textarea>
    </div>
    <div class="form-group">
    <input type="submit"  class="btn btn-primary" value="visit Info">
    </div>
@endsection
