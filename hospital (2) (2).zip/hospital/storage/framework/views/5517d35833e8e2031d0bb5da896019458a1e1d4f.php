<?php $__env->startSection('content'); ?>
<h1>Patients Details..</h1>
<h5><?php echo e($hospital->name); ?></h5>
Medicines:
<h6><?php echo e($hospital->medicines); ?></h6>
Disease:
<h6><?php echo e($hospital->disease); ?></h6>

<?php
$i=1;
?>
<ul>
    <?php $__empty_1 = true; $__currentLoopData = $hospital->getVisits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
     <li>
        <lable for="">visits <?php echo e($i++); ?></lable>
        <p> <?php echo e($visit->disease); ?></p>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <li> No more visits found</li>

    <?php endif; ?>
</ul>

<form action="<?php echo e(route('visit.store')); ?>"method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="patients_id" value=<?php echo e($hospital->id); ?>>
    <div class="form-group">
        <label>Example textarea</label>
          <textarea name="disease" class="form-control" rows="3"></textarea>
    </div>
    <div class="form-group">
    <input type="submit"  class="btn btn-primary" value="visit Info">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\hospital\resources\views/hospital/show.blade.php ENDPATH**/ ?>