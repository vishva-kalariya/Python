
	<?php $__env->startSection('content'); ?>
	<h1>Edit patients information here...</h1>

<form action="<?php echo e(route('hospital.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
  <div class="form-group">
    <label>patients name</label>
    <input type="text" name="name" class="form-control" value="<?php echo e($hospital->name); ?> "placeholder="Enter patients name">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>

  <div class="form-group">
    <label>mobile</label>
    <input type="text" valur="<?php echo e($hospital->mobile); ?>" name="mobile" class="form-control" placeholder="enter mobile number">
  </div>

  <div class="form-group">
    <label for="exampleFormControlTextarea1">diseases</label>
    <textarea id="editor" name="disease" class="form-control"  rows="3"><?php echo e($hospital->disease); ?></textarea>
  </div>


<div class="form-group">
    <label for="exampleFormControlTextarea1">medicines</label>
    <textarea id="editor" name="medicines" class="form-control"  rows="3"><?php echo e($hospital->medicines); ?></textarea>
  </div>

  <input type="submit" class="btn btn-primary" value="Edit me!>
</form>

      <script>
        ClassicEditor
            .create( document.querySelector( '#editor' ) )
            .catch( error => {
                console.error( error );
            } );
    </script>

          <?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\hospital\resources\views/hospital/edit.blade.php ENDPATH**/ ?>