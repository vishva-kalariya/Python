import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

function Home() {
    const [title, setTitle] = useState([]);
    const logo = "http://10.9.39.82:8000/";

    function fetchDataHandler() {
        fetch('http://10.9.39.82:8000/api/setb')
            .then((response) => response.json())
            .then((data) => {
                setTitle(data.data);
            });
    }

    return (
        <Container>
            <Row className="mt-4">
                <Col>
                    <Button variant="primary">Breakfast</Button>
                </Col>
                <Col>
                    <Button variant="primary">Lunch</Button>
                </Col>
                <Col>
                    <Button variant="primary">Evening</Button>
                </Col>
                <Col>
                    <Button variant="primary">Dinner</Button>
                </Col>
                <Col>
                    <Button variant="warning">All</Button>
                </Col>
            </Row>
            <Row className="mt-4">
                {title.map((list) => (
                    <Col key={list.id} xs={12} sm={6} md={4} lg={3}>
                        <Card style={{ marginBottom: '20px' }}>
                            <Card.Img variant="top" src={`${logo}${list.image}`} />
                            <Card.Body>
                                <Card.Title>{list.name}</Card.Title>
                                <Card.Text>{list.category}</Card.Text>
                                <Card.Text>{list.description}</Card.Text>
                                <Button variant="danger">Order Now</Button>
                            </Card.Body>
                        </Card>
                    </Col>
                ))}
            </Row>
            <Button className="mt-4" variant="primary" onClick={fetchDataHandler}>Show</Button>
            
        </Container>
    );
}

export default Home;





