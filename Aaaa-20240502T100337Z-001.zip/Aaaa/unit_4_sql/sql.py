# creating a database
# import mysql.connector
# mydb=mysql.connector.connect(host='localhost',user='root',password='')
# mycursor=mydb.cursor()
# mycursor.execute('CREATE DATABASE mypy')

# creating a table
# import mysql.connector
# mydb=mysql.connector.connect(host='localhost',user='root',password='',database='mypy')
# mycursor=mydb.cursor()
# mycursor.execute('CREATE TABLE stud_data(roll int,name varchar(25))')

# inserting the records in table

# import mysql.connector
# try:
# 	mydb=mysql.connector.connect(host='localhost',user='root',password='',database='mypy')
# 	my_insert_query='INSERT INTO stud_data(roll,name)VALUES(%s,%s)'
# 	record_to_insert=[(1,'sunday'),(2,'monday'),(3,'tuesday')]
# 	cursor=mydb.cursor()
# 	cursor.executemany(my_insert_query,record_to_insert)
# 	mydb.commit()
# 	print('record insert suvvessfully')
# except mysql.connector.Error as error:
# 	print('Fails to insert data')
# finally:
# 	 if mydb.is_connected():
# 		 cursor.close()
# 		 print('mysql connection is closed successfully')


# display the record inserted in the table

# import mysql.connector
# mydb=mysql.connector.connect(host='localhost',user='root',password='',database='mypy')
# mycursor=mydb.cursor()
# mycursor.execute('SELECT*FROM stud_data')
# result=mycursor.fetchall()
# for i in result:
# 	print(i)

# updating record

# import mysql.connector
# mydb=mysql.connector.connect(host='localhost',user='root',password='',database='mypy')
# mycursor=mydb.cursor()
# update_query="UPDATE stud_data SET roll=5 WHERE name='monday'"
# mycursor.execute(update_query)
# mydb.commit()

# deleting record
import mysql.connector
mydb=mysql.connector.connect(host='localhost',user='root',password='',database='mypy')
mycursor=mydb.cursor()
mycursor.execute("DELETE FROM stud_data WHERE roll=2")
mydb.commit()
mydb.close()
# ===========================================================================================
#database connectivity of python with sqlite
# creating database
import sqlite3
cnt=sqlite3.connect('mydb.dp')
# creating a table stud_data
# cnt.execute('CREATE TABLE stud_data(roll integer,name varchar)')
# print('table created')
# inserting the record in table stud_data
# cnt.execute("""
# 	        INSERT INTO stud_data VALUES
# 	        (1,'sunday'),
# 	        (2,'monday'),
# 	        (3,'tuesday')
	     
# """)
# print('record insert successfully')
# cnt.commit()

# retrieving the record from table
# cursor=cnt.execute('SELECT* FROM stud_data')
# for i in cursor:
# 	print(i)

# retrieving the record whose roll is greater than 2.
# cursor=cnt.execute('SELECT* FROM stud_data WHERE roll>2')
# for i in cursor:
# 	print(i)

# updating the record whose roll no is 3
# sql_upd="""UPDATE stud_data SET name='wednesday'WHERE roll=3"""
# cnt.execute(sql_upd)
# cursor=cnt.execute('SELECT*FROM stud_data')
# for i in cursor:
# 	print(i)


# deleting the record whose roll no is 3
# sql_del="""DELETE FROM stud_data WHERE ROLL=3"""
# cnt.execute(sql_del)
# cursor=cnt.execute('SELECT * FROM stud_data')
# for i in cursor:
# 	print(i)
