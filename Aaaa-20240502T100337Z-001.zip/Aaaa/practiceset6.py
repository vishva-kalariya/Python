# 1. Create a file with file name sample.txt, accept some data from the user and store it in the file.
# f=open('sample1','w')
# str1=input('enter the data you want to write into file:')
# f.write(str1)
# f.close()
# output:
# enter the data you want to write into file:this is a 1st program of practicset-6

# 2. Display the data stored in the sample.txt file (created in question 1).
# f=open('sample1','r')
# str1=f.read()
# print(str1)
# f.close()
# output:
# this is a 1st program of practicset-6

# 3. Accept some data from the user and append it into the file sample.txt (created in question 1),
# also the data in the file.
# f=open('sample1','a')
# str1=input('enter the data you want to write in file:')
# f.write(str1)
# f.close()
# output:
# enter the data you want to write in file:this is a append


# 4. Accept the file name from the user, check the availability of the file: i). If the file exists display
# the data on the screen, ii). If the file is not available, display the appropriate message.
# import os 
# fname=input('enter the name of file to open:')
# if os.path.isfile(fname):
# 	f=open(fname,'r')
# 	str1=f.read()
# 	print(str1)
# else:
# 	print('the file does not exist')
# f.close()


# 5.Accept the file name from the user, check the availability of the file:
# a. If the file exists, display: i). No. of characters, ii). No. of words and iii). No. of lines
# b. If the file does exist, than display the appropriate message.
# import os
# fname=input('Enter the name of files to open:')
# if os.path.isfile(fname):
# 	f=open(fname,'r')
# else:
# 	print(fname+'does not exist')


# 6.Create and open the binary file with ‘with’ option. Store names of all the subjects you study in
# semester 2. Ask user to enter the subject number they wanted to see and display that subject
# name.


# 7.Create a file named ‘img1’, store an image into it. Open another file named ‘img2’, copy the
# same image as in the file ’img1’. Also store both files into the zip file named
# f=open('img1.jpg','rb')
# f1=open('img2.jpg','wb')
# img=f.read()
# f1.write(img)
# f.close()
# f1.close()


# 8.Create a file with ‘with’ option, name it as ‘marks.dat’.
# i). Accept subject name and marks from the user, store the data in the file.
# ii). Give three options to the user: a). To view whole file, b). Accept and edit the marks of a
# subject user want to change.
# iii). Exit


# 9.Create a regular expression that:
# (A)Identifies and display the string starting with ‘s’ and having 4 characters.
# import re
# prog=re.compile(r's\w\w\w')
# str1='skye star sun stars view '
# result=prog.search(str1)
# print(result.group())=========================================

# (B)Splits the string where some special characters are found.
# import re                                        
# str1='hello! my name is vishva, i from M; CA'    
# result=re.split(r'\w+',str1)                     
# print(result)==========================================


# (C)Display the word starting with number.


# (D)Display the word having 3 or 4 or 5 characters.
# import re 
# str1='sky star sun stars view on sunset'
# result=re.findall(r'\b\w{3,5}\b',str1)
# print(result)
# output:
# ['sky', 'star', 'sun', 'stars', 'view']


# (E)Display only the dates from the string.
# import re
# str1='001 abc 1-10-2003, 002 def 26-6-2020, 003 ghi 23-5-19'
# result=re.findall(r'\d{1,2}-\d{1,2}-\d{2,4}',str1)
# print(result)
# output:
# ['1-10-2003', '26-6-2020', '23-5-19']

# (F)Create a string with name of the person and his Aadhar number, display only Aadhar
# number.

# import re 
# str1='vishva 123654789129, mansi 159874562314, presha 456982315975'
# result=re.findall(r'\d{12}',str1)
# print(result)
# output:
# ['123654789129', '159874562314', '456982315975']

# (G)Display all the words that starts with ‘at’ or ‘ap’.
# import re 
# str1='apple atmosphere mango banana apply'
# result=re.findall(r'a[pt][\w]*',str1)
# print(result)
# output:
# ['apple', 'atmosphere', 'apply']

# (H)Check if the string starts with ‘at’ than display appropriate message and otherwise.
# import re 
# str1='Atmiya university'
# result=re.search(r'^At',str1)
# if result:
# 	print('the str start with At')
# else:
# 	print('the str does not start with At')
# output:
# the str start with At


# 10. Do as directed:
# a). Name the package used to deal with data frame.
# b). Name the package used to deal with data .xlsx file.
# c). Name the function used to read the .csv file.
# d). Name the function used to read the .xlsx file.
# e). Name the function used to read the tuple.


# 11.Create a dictionary which stores (at least 10 records)empid, name, city, salary and perform
# following operations:

# import pandas as pd 
# emp={'empid':[1,2,3,4,5,6,7,8,9,10],'name':['abc','def','ghi','jkl','mno','pqr','stu','vwx','xyz','omg'],'city':['rajkot','surat','bhuj','goa','diu','gondal','mumbai','disa','abu','ambaji'],'salary':[1000,2000,3000,4000,30000,6000,7000,26000,9000,25000],'perform':['manager','ca','cs','hrmanager','security','helper','worker','superwiser','marketingman','productionman']}
# df=pd.DataFrame(emp,columns=['name','city','salary','perform'])
# print(df)

# (A)Display first three records
# print(df.head(3))
# output:
#   name    city  salary  perform
# 0  abc  rajkot    1000  manager
# 1  def   surat    2000       ca
# 2  ghi    bhuj    3000       cs

# (B)Display last five records
# print(df.tail())
# output:
#   name    city  salary        perform
# 5  pqr  gondal    6000         helper
# 6  stu  mumbai    7000         worker
# 7  vwx    disa    8000     superwiser
# 8  xyz     abu    9000   marketingman
# 9  omg  ambaji   10000  productionman

# (C)Display only Name and City
# print(df[['name','city']])
# output:
#   name    city
# 0  abc  rajkot
# 1  def   surat
# 2  ghi    bhuj
# 3  jkl     goa
# 4  mno     diu
# 5  pqr  gondal
# 6  stu  mumbai
# 7  vwx    disa
# 8  xyz     abu
# 9  omg  ambaji

# (D)Display employee who belongs to Mumbai
# print(df[df.city=='mumbai'])
# output:
# 6  stu  mumbai    7000  worker

# (E)Display employee name who belongs to Mumbai
# print(df[['name']][df.city=='mumbai'])
# output:
#   name
# 6  stu

# (F)Display employee whose salary is more than 25000
# print(df[df.salary>25000])
# output:
#   name  city  salary     perform
# 4  mno   diu   30000    security
# 7  vwx  disa   26000  superwiser


#12. Create an xlsx file store marks of five subjects, plot the data on the bar graph.
# import pandas as pd 
# import matplotlib.pyplot as plt 
# import xlrd
# df=pd.read_excel('stud.xlsx')
# print(df)
# x=df['Student']
# y=df['Marks']
# plt.bar(x,y,label='subject_wise_marks_of_students',color='pink')
# plt.xlabel('Student_name')
# plt.ylabel('Subject_marks')
# plt.title('Atmiya university')
# plt.legend()
# plt.show()

# 13.Take five income source of the Government and display it on the pie chart.
# import matplotlib.pyplot as plt 
# income=[20000,50000,30000,45000,25000]
# income_source=['Taxes','Excise duties','Tax complexity','Payroll taxes','Veterinary tax']
# col=['pink','green','red','purple','yellow']
# plt.pie(income,labels=income_source,colors=col)
# plt.title('Tax office')
# plt.legend()
# plt.show()


# 14.Draw the line chart representing BSE (Bombay Stock Exchange) index in last 10 years.
# import matplotlib.pyplot as plt 
# year=['2014','2015','2016','2017','2018','2019','2020','2021','2022','2023']
# prise=[10200,10000,10800,10900,10500,10000,11000,11500,9800,10400]
# plt.plot(year,prise,color='blue')
# plt.title('Bombay Stock Exchange(last 10 years)')
# plt.xlabel('years')
# plt.ylabel('up & down price')
# plt.show()


# 15. Plot the grouped bar graph using the appropriate data.
import matplotlib.pyplot as plt 
x=[101,109,103,107,110]
y=[10010,11109,20003,25007,31010]
x1=[105,108,102,106,111]
y1=[20110,31109,35003,29007,39010]
plt.bar(x,y,label='production department',color='pink')
plt.bar(x1,y1,label='qa department',color='blue')
plt.xlabel('employee id')
plt.ylabel('salary')
plt.title('tata services')
plt.legend()
plt.show()