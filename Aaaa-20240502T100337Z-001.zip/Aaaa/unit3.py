#            UNIT-3

# FUNCTION:
# =========

# def sum (a,b):
# 	addition=a+b
# 	return(addition)
# q=sum(5,4)
# print('sum of two digits:',q)
# o/p:
# sum of two digits: 9


# value is odd or evan
# def oe(number):
# 	if number%2==0:
# 		print('the entered number is even:')
# 	else:
# 		print('the entered number is odd')
# oe(26)
# o/p:
# the entered number is even:

# num is positive negative or zero using function
# def pnz(number):
# 	if number>0:
# 		print('num is positive:')
# 	elif number==0:
# 		print('num is zero:')
# 	else:
# 		print('num is nagative:')
# number=int(input('enter the number:'))
# pnz(number)
# o/p:
# enter the number:-10
# num is nagative:


# returning multiple values from function
# def arith(a,b):
# 	add=a+b
# 	sub=a-b
# 	div=a/b
# 	mul=a*b 
# 	return add,sub,div,mul
# a,s,d,m=arith(10,5)
# print('addition is:',a)
# print('subtraction is:',s)
# print('division is:',d)
# print('multiplication is:',m)
# o/p:
# addition is: 15
# subtraction is: 5
# division is: 2.0
# multiplication is: 50


# PASSING BY OBJECT

# for immutable:
# pass integer to a function & modify it
# def mod(a):
# 	a=7
# 	print('the value of a,inside the function is:',a)
# a=9
# mod(a)
# print('the value of a,outside the function is:',a)
# o/p:
# the value of a,inside the function is: 7
# the value of a,outside the function is: 9

# for mutable:

# def mod(a):
# 	lst.append(266)
# 	print(lst,id(lst))
# lst=[1,2,3,4,5,6]
# mod(lst)
# print(lst,id(lst))
# o/p:
# [1, 2, 3, 4, 5, 6, 2] 1963129718656
# [1, 2, 3, 4, 5, 6, 2] 1963129718656

# ACTUAL ARGUMENTS IN A FUNCTION CALL ARE 4TYPES

# POSITIONAL ARGUMENTS
# ======================

# def conc(s1,s2):
# 	s3=s1+s2
# 	print(s3)
# conc('vishva','kalariya')
# conc('atmiya','university')
# conc('vishva')           } error
# conc('atmiya','university','abc')  } error
# o/p:
# vishvakalariya
# atmiyauniversity


#KEYWORD ARGUMENT
# ==================

# def emp(eid,name):
# 	print('the employee id is:',eid)
# 	print('the employee name is:',name)
# emp(eid=101,name='vish')
# emp(name='abc',eid='202')
# o/p:
# the employee id is: 101
# the employee name is: vish
# the employee id is: 202
# the employee name is: abc

#default ARGUMENT
# def emp(eid,name='xyz'):
# 	print('the employee id is:',eid)
# 	print('the employee name is:',name)
# emp(eid=101)
# emp(eid='202')
# o/p:
# the employee id is: 101
# the employee name is: xyz
# the employee id is: 202
# the employee name is: xyz


# variable length ARGUMENT
# def addition (farg,*args):
# 	sum=0
# 	for i in args:
# 		sum=sum+i
# 	print('sum of all numbers is:',(farg+sum))
# addition(2,5)
# o/p:
# sum of all numbers is: 7

# passing group of element to function
# def disp (lst):
# 	for i in lst:
# 		print(i)
# print('enter element seprated by space:',end='')
# lst=[a for a in input().split()]
# disp(lst)
# o/p:
# enter element seprated by space:10 20 30
# 10
# 20
# 30


# anonymous funcrion LAMBDA

# sqr=lambda a:a*a 
# a=int(input('enter the value:'))
# print('square of num is:',sqr(a))
# o/p:
# enter the value:5
# square of num is: 25

# find biggest num using LAMBDA

# big=lambda a,b:a if a>b else b 
# a=int(input('enter the value of a:'))
# b=int(input('enter the value of b:'))
# print('bigger num is:',big(a,b))
# o/p:
# enter the value of a:20
# enter the value of b:30
# bigger num is: 30

# genrators:

# def generator(a,b):
# 	while a<=b:
# 		yield a
# 		a=a+1
# gen=generator(1,10)
# for i in gen:
# 	print(i,end='')
# o/p:
# 12345678910

# FILE HANDLING
# ================

# OPEAN A FILE

# f=open('file2','w')
# str1=input('enter the data you want to write into file:')
# f.write(str1)
# f.close()
# # o/p:
# je data lakhsu te text file ma show thase

# READ THE EXISTING FILE
# f=open('file2','r')
# str1=f.read
# print(str1)
# f.close()

# error

# APPEND INTO FILE
# f=open('file2','a')
# str1=input('enter the data you want to write in file:')
# f.write(str1)
# f.close()
# o/p: file a data avse


# checking whether file exists or not
import os 
fname=input('enter the name of fileto open:')









# create a regular expression that finds the words starting with new string
# import re
# str1='Sub shines sooner or later'
# result=re.findall(r's[\w]*',str1)
# print(result)
# ['shines', 'sooner']

# create a regular expression that finds the words starting witha number
# import re
# str1='the special classes are arranged on 11th and 21st of every month'
# result=re.findall(r'\d[\w]*',str1)
# print(result)
# ['11th', '21st']

# create a regular expression that retrivee the words having 5 charcter
# import re
# str1='sun mon tues wedn thurs frida saturday'
# result=re.findall(r'\b\w{5}\b',str1)
# print(result)
# ['thurs', 'frida']

# create a regular expression that retrieve the words having 3 or 4 charcter
# import re
# str1='sun mon tues wedn thurs frida saturday'
# result=re.findall(r'\b\w{3,5}\b',str1)
# print(result)
# ['sun', 'mon', 'tues', 'wedn']

# create a regular expression that retrieve the words having 3,4 or 5charcter
# import re
# str1='sun mon tues wedn thurs frida saturday'
# result=re.findall(r'\b\w{3,5}\b',str1)
# print(result)
# ['sun', 'mon', 'tues', 'wedn', 'thurs', 'frida']

# min 4 characer max gme tetla chale
# import re
# str1='sun mon tues wedn thurs frida saturday'
# result=re.findall(r'\b\w{4,}\b',str1)
# print(result)
# ['tues', 'wedn', 'thurs', 'frida', 'saturday']

# create a regular expression that retrieve only single digits from string
# import re
# str1='one three five seven 8 9 10'
# result=re.findall(r'\b\d\b',str1)
# print(result)
# ['8', '9']

# create a regular expression that retrieve double digits from string
# import re
# str1='one three five seven 8 9 10'
# result=re.findall(r'\b\d\d',str1)
# print(result)
# ['10']


# min 2 digits max gme tetla
# import re
# str1='one three five seven 8 9 10 100 1011'
# result=re.findall(r'\b\d{2,}',str1)
# print(result)
# ['10', '100', '1011']

#create a regular expression that retrieve the last word of a  string start eith 's'
# import re 
# str1='sun moon stats planets galaxy stars'
# result=re.findall(r's[\w]*\Z',str1)
# print(result)
# ['star']

#create a regular expression to retrieve the word of string start with 's'
# import re 
# str1='sun moon stats planets galaxy star'
# result=re.findall(r'\As[\w]*',str1)
# print(result)
# ['sun']

# # bar graph unit=5

# import matplotlib.pyplot as plt 
# x=[101,109,103,107,110]
# y=[10010,11109,20003,25007,31010]
# x1=[105,108,102,106,111]
# y1=[20110,31109,35003,29007,39010]
# plt.bar(x,y,label='production department',color='pink')
# plt.bar(x1,y1,label='qa department',color='blue')
# plt.xlabel('employee id')
# plt.ylabel('salary')
# plt.title('tata services')
# plt.legend()
# plt.show()

# pie chart UNIT=5

# import matplotlib.pyplot as plt 
# depart_stud=[24,18,18,29,11]
# programs=['MCA','MBA','MCOM','MSCIT','MSC']
# col=['pink','green','red','blue','yellow']
# plt.pie(depart_stud,labels=programs,colors=col)
# plt.title('ATMIYA UNIVERSITY')
# plt.legend()
# plt.show()


# LINE GRAPH UNIT=5
# import matplotlib.pyplot as plt 
# years=['2023','2022','2021','2020','2019']
# incre_pop=[89,78,65,94,55]
# plt.plot(years,incre_pop,color='blue')
# plt.title('population growth in india (last 5 years)')
# plt.xlabel('years')
# plt.ylabel('increase of population in lakhs')
# plt.show()

#DOUBLE LINE GRAPH UNIT=5
# import matplotlib.pyplot as plt 
# years=['2023','2022','2021','2020','2019']
# ind_pop=[89,78,65,94,55]
# uk_pop=[50,89,94,65,55]
# plt.plot(years,ind_pop,color='blue')
# plt.plot(years,uk_pop,color='red')
# plt.title('population growth in india (last 5 years)')
# plt.xlabel('years')
# plt.ylabel('increase of population in lakhs')
# plt.show()
