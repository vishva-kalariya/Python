#1. Write a Python program to find area of a triangle.

# b=float(input('enter value of base:'))
# h=float(input('enter value of height:'))
# print(b*h/2)

#2.wap to find area of square
# a=float(input('enter the value:'))
# print('area of square:',a*a)

#3.wap to convert celcius to farenhit
# c=float(input('enter the value of celcius:'))
# f=(c*9/5+32)
# print('farenhit is:',f)


#4.wap to find us dollar to indian rupees
# a=float(input('enter value of US dollar:'))
# print('indian ruppes:',a*82.88)

#5.wap to convert to liter to mililiter
# a=float(input('enter value of liter:'))
# print('mililiter:',a*1000)

#6.Enter binary, octal and hexadecimal values and convert it into decimal.
# a='01101'
# b=int(a,2)
# print(b)

# a='0123'
# b=int(a,8)
# print(b)

# a='0123'
# b=int(a,16)
# print(b)

# 7. Accept one integer value from the user; convert it to binary, octal and hexadecimal.
# a=int(input('enter integer value:'))
# binary=bin(a)
# print(binary)

# octal=oct(a)
# print(octal)

# hexadecimal=hex(a)
# print(hexadecimal)


# 8. Accept string from the user (‘The Rajkot is a good city to leave’), and do the following
# operations: i). Display the first character of the string, ii). Display the first character of the string
# using negative index, iii). Display ‘Rajkot is a good city’. iv). Display the last character.

a=str(input('enter a string: '))
print('Display the first character of the string:',a[0])
print('Display the first character of the string using negative index:',a[-34])
print('Display ‘Rajkot is a good city’:',a[0])
print('Display the last character’:',a[-1])