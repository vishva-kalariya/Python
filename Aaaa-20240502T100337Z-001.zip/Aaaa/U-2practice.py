
                         # UNIT=2


# ===posion thi delete==

# num=(1,2,3,4,5)
# print(num)
# lst=list(num)
# print(lst)
# a=int(input('enter an postion to delete:'))
# # lst.remove(2)
# del lst[2]
# print(lst)

#==indexing and slicing on array==

# from array import*
# a=array ('i',[10,20,30,40,50])
# n=len(a)
# print(n)
# for i in range(n):
# 	print(a[i],end=',')

#==slicing==
# from array import*
# c=array('u',['a','t','m','y'])
# a=c[0:3]
# print(a)

# ====array method=====
# from array import*
# ar=array('i',[1,2,3,4,5,10])
# ar.append(6)
# print(ar)
# print('after append:',ar)

# ar.insert(0,0)
# ar.insert(2,8)
# print('after insert:',ar)
# after insert: array('i', [0, 1, 8, 2, 3, 4, 5])

# ar.remove(3)
# ar.remove(1)
# print('after removr:',ar)
# after removr: array('i', [1, 2, 4, 5])
# after removr: array('i', [2, 4, 5])

# a=ar.pop()
# print('the element poped is:',a)
# print('after remvoing last value is:',a)
# the element poped is: 10
# after remvoing last value is: 10

# a=ar.tolist()
# print('value of array are:',ar)
# print('list are:',a)
# value of array are: array('i', [1, 2, 3, 4, 5, 10])
# list are: [1, 2, 3, 4, 5, 10]

#====display % using array======

# from array import*
# str=input('enter marks:').split(' ')
# marks=[int(num)for num in str]
# total=0
# for a in marks:
# 	total=total+a
# print('the total score is:',total)
# l=len(marks)
# percent=total/l
# print('percentage is:',percent)
# enter marks:20 30 50 60
# the total score is: 160
# percentage is: 40.0

#===single dimen array====
# from array import*
# marks=array('i',[10,20,30,40,50])
# print(marks)

#===Arrange()====
# from numpy import*
# a=arange(2,10,2)
# print(a)

# =====operation on array====
# from numpy import*
# a=array([40,30,20,-10])
# print(a)
# print('adding 5 to each elements of an array:',a+5)
# print('Substraction 5:',a-5)
# print('Multiplication 5:',a*5)
# print('Division5:',a/5)
# print('max value:',max(a))
# print('sum of value:',sum(a))
# print('finding average:',mean(a))

# ======comparing array============
# from numpy import*
# a=array([1,2,3,4,5,6,7])
# b=array([3,2,8,5,4,2,9])
# c=where(a>b,a,b)
# print(c)
# o/p:[3 2 8 5 5 6 9]

# =====non zero elements======
# from numpy import*
# a=array([1,2,3,0,8,0])
# b=nonzero(a)
# print(a[b])
# o/p:[1 2 3 8]


# ======VIEW of an existing array======
# from numpy import*
# a1=array([10,20,30,40,50,60,70,80,100])
# b1=a1.view()
# print('elements of an array a1 are:',a1)
# print('elements of an array b1 are:',b1)
# b1[4]=500
# print('b1 after modification are:',b1)
# print('a1 after modification are:',a1)
# o/p:
# elements of an array a1 are: [ 10  20  30  40  50  60  70  80 100]
# elements of an array b1 are: [ 10  20  30  40  50  60  70  80 100]
# b1 after modification are: [ 10  20  30  40 500  60  70  80 100]
# a1 after modification are: [ 10  20  30  40 500  60  70  80 100]


# =======copy() of array=======
# from numpy import*
# a=array([10,20,30,40,50,60,70,80,100])
# b=a.copy()
# print('elements of a array:',a)
# print('elements of b array:',b)
# o/p:
# elements of a array: [ 10  20  30  40  50  60  70  80 100]
# elements of b array: [ 10  20  30  40  50  60  70  80 100]


# ======slicing using numpy array=======
# from numpy import*
# a=array([10,20,30,40,50,60,70,80,100])
# # print(a)
# # print(a[0:6:2])
# # print(a[::])
# print(a[2::2])
# print(a[2:])

# ======indexing using numpy=========
# from numpy import*
# a=array([10,20,30,40,50,60,70,80,90])
# print(a)
# i=0
# while(i<len(a-1)):
#     print(a[i],end=',')
#     i=i+1
# o/p:[10 20 30 40 50 60 70 80 90]
# 10,20,30,40,50,60,70,80,90,


#================= ATRIBUTE OF AN ARRAY=========

# ==========.ndim=========
# from numpy import*
# a=array([10,20,30,40,50,60,70,80,90])
# print(a.ndim)
# b=array([[10,20,30,40,50],[60,70,80,90,100]])
# print(b)
# print(b.ndim)
# o/p:
# 1
# [[ 10  20  30  40  50]
# [ 60  70  80  90 100]]
# 2

# ==========shape()=========
# a=array([10,20,30,40,50,60,70,80,90])
# print(a.shape)
# b=array([[10,20,30,40,10],[50,60,70,80,10],
#          [20,30,50,40,10],[100,20,50,80,10]])
# print(b.shape)
# o/p:
# (9,)
# (4, 5)

# ==========dtype()=========
# a=array([10,20,30,40,50,60,70,80,90,100])
# print(a.dtype)
# o/p:int32

# ==========reshape()=========
# a=array([10,20,30,40,50,60,70,80,90,100,110,120])
# a=a.reshape(3,4)
# print(a)
# o/p:
# [[ 10  20  30  40]
#  [ 50  60  70  80]
#  [ 90 100 110 120]]

# =======flatten()========
# a=array([10,20,30,40,50,60,70,80,90,100])
# a=a.flatten()
# print(a)
# o/p:[ 10  20  30  40  50  60  70  80  90 100]

# =========size()============
# a=array([10,20,30,40,50,60,70,80,90,100])
# print(a.size)
# b=array([[10,20,30,40,10],[50,60,70,80,10],[20,30,50,40,10],[100,20,50,80,10]])
# print(b.size)
# o/p:
# 10
# 20

# ==========reshape in multi dimensional array=======
# a=array([1,2,3,4,5,6,7,8,9,10,11,12])
# print(a)
# b=reshape(a,(6,2))
# print(b)
# c=reshape(a,(2,2,3))
# print(c)
# o/p:
# [ 1  2  3  4  5  6  7  8  9 10 11 12]  a
# [[ 1  2]  b
#  [ 3  4]
#  [ 5  6]
#  [ 7  8]
#  [ 9 10]
#  [11 12]]

# [[[ 1  2  3]  c
#   [ 4  5  6]]

#  [[ 7  8  9]
#   [10 11 12]]]

# ==========indexing in multi dimensional array=======
# a=array([[10,20,30,40,10],[50,60,70,80,10],[20,30,50,40,10],[100,20,50,80,10]])
# for i in range(len(a)):
#     print(a[i])
#     pass
# for i in range(len(a)):
#     for j in range(len (a[i])):
#         print(a[i][j],end=',')
# o/p:
# [10 20 30 40 10]
# [50 60 70 80 10]
# [20 30 50 40 10]
# [100  20  50  80  10]
# 10,20,30,40,10,50,60,70,80,10,20,30,50,40,10,100,20,50,80,10,


# ==========slicing in multi dimensional array=======
# a=array([[10,20,30,40,10],[50,60,70,80,10],[20,30,50,40,10],[100,20,50,80,10]])
# print(a[1,:])   o/p--->     [50 60 70 80 10]
# print(a[:,0])   o/p--->     [ 10  50  20 100]
# print(a[0:1,0:1]) o/p--->     [[10]]


# ===============STRING====================
# s1='welcome to atmiya university,rajkot'
# s2='welcome to atmiya university,rajkot'
# print(s1)
# print(s2)
# s3='welcomr to "atmiya university",rajkot'
# print(s3)
# o/p:s3
# welcomr to "atmiya university",rajkot
# s4='welcome to \t"atmiya university",\n rajkot'
# print(s4) 
# o/p:s4                               
# welcome to      "atmiya university",
# rajkot
# s5='r' 'welcome to \t"atmiya university",\n rajkot'
# print(s5)
# # o/p:s5                               
# # welcome to      "atmiya university",
# # rajkot
# print(s5)
# print(len (s1))
# print(s1*2)
# s6="ATMIYA"
# s7='university'
# s7=567567
# print(s7)


# ==============string using while==========
# st='atmiya university'
# n=len(st)
# i=0
# while i<n:
#     print(st[i],end='')
#     i=i+1
# print
# o/p:atmiya university

# ==============string using for loop==========
# st='atmiya university'
# i=0
# for i in st:
#     print (i,end='')
#     print()
# # o/p:
# D:\>python labpra.py
# a
# t
# m
# i
# y
# a

# u
# n
# i
# v
# e
# r
# s
# i
# t
# y

# ========slicing the string=======

# st='atmiya university'
# print(st[0:17:1])
# print(st[0:17:2])
# print(st[-1::])
# o/p:
# atmiya university
# amy nvriy
# y

# ======string exist in the main string=======

# st=input('enter the main string:')
# subset=input('enter the string you want to find from main string:')
# if subset in st:
#     print(subset,'is available in the main string')
# else:
#     print(subset,'is not available in the main string')
# o/p:
# enter the main string:hello! My name is vishva kalariya
# enter the string you want to find from main string:shva
# shva  is available in the main string

# =======check wether entered string is palindrom========

# st=input('enter the string to check:')
# st1=(st[-1::-1])
# print(st1)
# if (st==st1):
#     print('enter string is palindrom')
# else:
#     print('enter string is not palindrom')
# o/p:
# enter the string to check:kalariya vishva
# avhsiv ayiralak
# enter string is not palindrom

# enter the string to check:nan
# nan
# enter string is palindrom

 # ======== changing the case of s string=======

# st='my name is Vishva'
# print(st.upper())        
# print(st.lower())
# print(st.swapcase())
# print(st.title())
# o/p:
# MY NAME IS VISHVA
# my name is vishva
# MY NAME IS vISHVA
# My Name Is Vishva

# =======isdigit()=======
# m_no=input('enter your mobile no:')
# print(m_no.isdigit())
# if m_no.isdigit():
#     print('valid mobile no')
# else:
#     print('not valid mobile no')
# o/p:
# enter your mobile no:gjbhngjmtr
# False
# enter valid mobile no

# enter your mobile no:69859623
# True
# valid mobile no

# # =========stort string in alphabetical order========

# st=[]
# n=int(input('how many string you want to elements:'))
# for i in range(n):
#     print('enter the string:',end='')
#     st.append(input())
#     print(st)
#     st1=st.sort()
#     print(st)
#     o/p:
# how many string you want to elements:3
# enter the string:vishva
# ['vishva']
# ['vishva']
# enter the string:aaa
# ['vishva', 'aaa']
# ['aaa', 'vishva']
# enter the string:presha
# ['aaa', 'vishva', 'presha']
# ['aaa', 'presha', 'vishva']

# ======know the type of character=========

# st=input('enter character:')
# ch=st[0]
# if ch.isalpha():
#     print('it is an alphabet')
#     if ch.upper():
#         print('you have to entered in upper case')
#     else:
#         print('you have to entered in lower case')
# else:
#     print('plzz enter some alphabet')
