package com.example.fristapp

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import java.util.*

class linearlayout : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_linearlayout)

        var time : EditText = findViewById(R.id.editTextTime)
        var date : EditText = findViewById(R.id.editTextDate)
        var c = Calendar.getInstance()

        time.setOnClickListener {
            TimePickerDialog(this,TimePickerDialog.OnTimeSetListener { timePicker, i, i2 ->
                time.setText("$i:$i2")
            },c.get(Calendar.HOUR), c.get(Calendar.MINUTE),false).show()
        }

        date.setOnClickListener {
            DatePickerDialog(this,DatePickerDialog.OnDateSetListener { datePicker, i, i2, i3 ->
                date.setText("$i:$i2:$i3")
            },c.get(Calendar.YEAR), c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()
        }
    }
}