package com.example.fristapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton

class Secondactivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_secondactivity)

        var ib1 : ImageButton = findViewById(R.id.imageButton5)
        var ib2 : ImageButton = findViewById(R.id.imageButton2)
        var ib3 : ImageButton = findViewById(R.id.imageButton3)
        var ib4 : ImageButton = findViewById(R.id.imageButton4)

        ib1.setOnClickListener {
            var i = Intent(this,constraintlayout::class.java)
            startActivity(i)
        }
        ib2.setOnClickListener {
            var i = Intent(this,linearlayout::class.java)
            startActivity(i)
        }
        ib3.setOnClickListener {
            var i = Intent(this,relativelayout::class.java)
            startActivity(i)
        }
        ib4.setOnClickListener {
            var i = Intent(this,framelayout::class.java)
            startActivity(i)
        }
    }
}