package com.example.fristapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast

class relativelayout : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_relativelayout)

        var lamp : Button = findViewById(R.id.toggleButton)
        var imagebtn : ImageButton = findViewById(R.id.imageButton6)
        var imgview : ImageView = findViewById(R.id.imageView)
//        var floatingActionButton : Button = findViewById(R.id.floatingActionButton)

        lamp.setOnClickListener {
            if(lamp.text.equals("OFF")){
                imgview.setImageResource(R.drawable.off)
            }else {
                imgview.setImageResource(R.drawable.on)
            }
        }

        imagebtn.setOnClickListener {
            Toast.makeText(applicationContext,"Atimya logo",Toast.LENGTH_LONG).show()
        }

    }
}