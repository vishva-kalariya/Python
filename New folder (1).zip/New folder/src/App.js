import { useState } from 'react';
import './App.css';
import Card from './Card';
import FetchData from './FetchData';
import Input from './Input';
import MyComponent from './MyComponent';
import Students from './Students';
import EventHandle from './EventHandle';


function App() {

  const [isLoggedIn, setIsLogin] = useState(false);
  function loginHandler() {
    setIsLogin(true);
  }
  return (

    <div className="App">
      <Input login={loginHandler} />
      <MyComponent isLoggedIn={isLoggedIn} />
      <Card title='Card Component' />
      <Students />
      <FetchData />
      <EventHandle />
    </div>
  );
}

export default App;
