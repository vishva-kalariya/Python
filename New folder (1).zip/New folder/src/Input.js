//8. get some input and display approprite

import React, { useRef } from 'react'

export default function Input({ login }) {

    const usernameinputref = useRef('');
    const passwordinputref = useRef('');

    const submitHandler = (e) => {
        e.preventDefault();
        alert(`name ${usernameinputref.current.value}, password ${passwordinputref.current.value}`)
        login();
    }


    return (
        <div style={{ backgroundColor: "yellow", padding: "20px" }}>
            <form onSubmit={submitHandler}>
                <label>Username</label>
                <input type='text' ref={usernameinputref} />
                <label>Password</label>
                <input type='text' ref={passwordinputref} />
                <button type='submit'>Submit</button>
            </form>
        </div>
    )
}
