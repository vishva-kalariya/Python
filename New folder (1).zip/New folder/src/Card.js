//2. create a component using funcion or class
//3. use props in component to pass the value

import React from 'react'

export default function Card(props) {
    return (
        <div style={{ backgroundColor: "gray", padding: "20px" }}>{props.title}</div>
    )
}
